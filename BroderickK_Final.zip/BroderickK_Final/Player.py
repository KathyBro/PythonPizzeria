
class player():
    def __init__(self):
        self.name = 'Player'
        self.math_grade = 0.0 # Percentage
        self.customers_served = 0
        self.current_day = 1